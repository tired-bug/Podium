# 🦋 Butterfly

A self-exploration platform where you chat with alternate versions of yourself based on different life paths.

## Stack (100% free)

| Layer       | Tech                                     |
|-------------|------------------------------------------|
| Frontend    | Next.js 14 (App Router)                  |
| Styling     | Tailwind CSS + custom CSS                |
| AI          | Groq API — llama-3.3-70b-versatile       |
| Deployment  | Vercel (free tier)                       |
| Database    | None — localStorage only                 |

## Features

- 16-question MBTI assessment in onboarding
- 5 AI-generated alternate life personas, deeply personalized
- MBTI type influences every persona's story and speaking style
- Chat interface with conversation history (localStorage)
- Interactive SVG path tree visualization

## Local Setup

1. Get a free Groq API key at console.groq.com (no credit card needed)
2. Run:
   npm install
   cp .env.example .env.local
   (edit .env.local with your key)
   npm run dev

## Deploy to Vercel

1. Push to GitHub
2. Import at vercel.com
3. Add env var: GROQ_API_KEY = your key
4. Deploy

## Project Structure

app/
  page.js                 Landing page
  onboarding/page.js      Multi-step form + MBTI quiz
  explore/page.js         Persona cards + path tree
  chat/[personaId]/       Chat with alternate self
  api/generate/route.js   Generate 5 personas
  api/chat/route.js       Chat completion

components/
  ButterflyIcon.jsx
  Stars.jsx

lib/
  mbti.js   Questions, calculator, 16 type descriptions
