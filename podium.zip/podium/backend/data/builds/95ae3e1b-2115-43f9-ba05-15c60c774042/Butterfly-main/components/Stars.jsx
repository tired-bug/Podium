'use client'
import { useRef } from 'react'

export default function Stars() {
  const stars = useRef(
    Array.from({ length: 100 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 0.4,
      dur: (Math.random() * 3 + 2).toFixed(1),
      del: (Math.random() * 5).toFixed(1),
      lo: (Math.random() * 0.06 + 0.02).toFixed(2),
      hi: (Math.random() * 0.4 + 0.1).toFixed(2),
    }))
  ).current

  return (
    <div className="stars-container">
      {stars.map((s) => (
        <div
          key={s.id}
          style={{
            position: 'absolute',
            left: `${s.x}%`,
            top: `${s.y}%`,
            width: `${s.size}px`,
            height: `${s.size}px`,
            borderRadius: '50%',
            background: 'white',
            animation: `starFloat ${s.dur}s ${s.del}s ease-in-out infinite alternate`,
            '--min-op': s.lo,
            '--max-op': s.hi,
          }}
        />
      ))}
    </div>
  )
}
