export default function ButterflyIcon({ size = 80 }) {
  const w = size
  const h = size * 0.78
  return (
    <svg width={w} height={h} viewBox="0 0 120 94" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="38" cy="34" rx="36" ry="26" fill="#5DD8E8" opacity="0.65" transform="rotate(-14 38 34)" />
      <ellipse cx="33" cy="58" rx="26" ry="17" fill="#B57BF5" opacity="0.55" transform="rotate(12 33 58)" />
      <ellipse cx="82" cy="34" rx="36" ry="26" fill="#B57BF5" opacity="0.65" transform="rotate(14 82 34)" />
      <ellipse cx="87" cy="58" rx="26" ry="17" fill="#5DD8E8" opacity="0.55" transform="rotate(-12 87 58)" />
      <ellipse cx="60" cy="46" rx="5" ry="24" fill="#EEF0FA" opacity="0.92" />
      <path d="M57 23 Q50 7 43 3" stroke="#EEF0FA" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.6" />
      <path d="M63 23 Q70 7 77 3" stroke="#EEF0FA" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.6" />
      <circle cx="43" cy="3" r="2.5" fill="#5DD8E8" />
      <circle cx="77" cy="3" r="2.5" fill="#B57BF5" />
    </svg>
  )
}
