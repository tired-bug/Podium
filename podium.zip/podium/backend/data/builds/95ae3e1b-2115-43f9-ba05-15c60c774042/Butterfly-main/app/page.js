import Link from 'next/link'
import Stars from '@/components/Stars'
import ButterflyIcon from '@/components/ButterflyIcon'

export default function HomePage() {
  return (
    <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px 24px', textAlign: 'center', position: 'relative' }}>
      <Stars />

      <div style={{ position: 'relative', zIndex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div className="float-anim" style={{ marginBottom: '36px' }}>
          <ButterflyIcon size={100} />
        </div>

        <h1 className="gradient-text fade-up" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 'clamp(72px, 10vw, 120px)', fontWeight: 300, letterSpacing: '-0.02em', lineHeight: 0.9, marginBottom: '22px' }}>
          butterfly
        </h1>

        <p className="fade-up-d1" style={{ fontSize: '17px', color: '#7880A0', maxWidth: '380px', lineHeight: 1.8, marginBottom: '16px', fontWeight: 300 }}>
          Every choice creates another version of you.
        </p>
        <p className="fade-up-d1" style={{ fontSize: '15px', color: '#2E3455', maxWidth: '340px', lineHeight: 1.8, marginBottom: '52px', fontWeight: 300 }}>
          Somewhere, that version already took the leap you&apos;re afraid to take. Come talk to them.
        </p>

        <div className="fade-up-d2" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
          <Link href="/onboarding" className="btn-primary">
            Begin Your Journey
          </Link>
          <span style={{ fontSize: '12px', color: '#2E3455', letterSpacing: '0.06em' }}>
            Takes 3 minutes · MBTI assessment included
          </span>
        </div>

        <div className="fade-up-d3" style={{ marginTop: '80px', display: 'flex', gap: '40px', flexWrap: 'wrap', justifyContent: 'center' }}>
          {[
            { emoji: '🚀', label: 'Startup Founder' },
            { emoji: '🌏', label: 'World Traveler' },
            { emoji: '🎨', label: 'Creative Artist' },
            { emoji: '🔬', label: 'Researcher' },
            { emoji: '✨', label: 'Future Self' },
          ].map((v) => (
            <div key={v.label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', opacity: 0.5 }}>
              <span style={{ fontSize: '28px' }}>{v.emoji}</span>
              <span style={{ fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#7880A0' }}>{v.label}</span>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
