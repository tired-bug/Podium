import './globals.css'

export const metadata = {
  title: 'Butterfly — Talk to your alternate selves',
  description: 'A self-exploration platform where you chat with alternate versions of yourself based on different life paths.',
  icons: { icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🦋</text></svg>" },
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
