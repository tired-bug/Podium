'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import Stars from '@/components/Stars'
import ButterflyIcon from '@/components/ButterflyIcon'
import { TYPES } from '@/lib/mbti'

function PathTree({ personas, onSelect }) {
  const cx = 300, cy = 52
  const nodes = [
    { x: 68, y: 230 }, { x: 175, y: 290 }, { x: 300, y: 308 },
    { x: 425, y: 290 }, { x: 532, y: 230 },
  ]
  return (
    <svg viewBox="0 0 600 340" style={{ width: '100%', height: 'auto' }}>
      <defs>
        <filter id="glow">
          <feGaussianBlur stdDeviation="2.5" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      {nodes.map((n, i) => {
        const col = personas[i]?.color || '#2E3455'
        const mx = (cx + n.x) / 2, my = (cy + n.y) / 2 - 30
        return (
          <path key={i} d={`M ${cx} ${cy + 20} Q ${mx} ${my} ${n.x} ${n.y - 28}`}
            stroke={col} strokeWidth="1.5" strokeDasharray="4 6" fill="none" opacity="0.4" />
        )
      })}
      <circle cx={cx} cy={cy} r="26" fill="rgba(93,216,232,0.1)" stroke="#5DD8E8" strokeWidth="1.5" filter="url(#glow)" />
      <text x={cx} y={cy + 5} textAnchor="middle" fill="#EEF0FA" fontSize="11" fontFamily="DM Sans, sans-serif">You</text>
      {nodes.map((n, i) => {
        const p = personas[i]
        const col = p?.color || '#2E3455'
        return (
          <g key={i} style={{ cursor: p ? 'pointer' : 'default' }} onClick={() => p && onSelect(p)}>
            <circle cx={n.x} cy={n.y} r="30" fill={`${col}18`} stroke={col} strokeWidth="1.5" filter="url(#glow)" />
            <text x={n.x} y={n.y + 2} textAnchor="middle" fill="#EEF0FA" fontSize="18">{p?.emoji || '·'}</text>
            <text x={n.x} y={n.y + 16} textAnchor="middle" fill={col} fontSize="8" fontFamily="DM Sans, sans-serif">
              {p?.type?.split(' ').slice(0, 2).join(' ') || ''}
            </text>
          </g>
        )
      })}
    </svg>
  )
}

export default function ExplorePage() {
  const router = useRouter()
  const [data, setData] = useState(null)

  useEffect(() => {
    const raw = localStorage.getItem('butterfly_data')
    if (!raw) { router.push('/onboarding'); return }
    setData(JSON.parse(raw))
  }, [])

  if (!data) return (
    <main style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Stars />
      <div style={{ position: 'relative', zIndex: 1, opacity: 0.5 }}><ButterflyIcon size={60} /></div>
    </main>
  )

  const { name, mbti, personas = [] } = data
  const mbtiInfo = TYPES[mbti] || {}

  return (
    <main style={{ minHeight: '100vh', paddingTop: '60px', paddingBottom: '100px', paddingLeft: '20px', paddingRight: '20px' }}>
      <Stars />

      <div style={{ position: 'relative', zIndex: 1, maxWidth: '920px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '48px' }}>
          <p style={{ fontSize: '11px', letterSpacing: '0.18em', textTransform: 'uppercase', color: '#7880A0', marginBottom: '14px' }}>Welcome back, {name}</p>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 'clamp(38px, 6vw, 62px)', fontWeight: 300, marginBottom: '20px', lineHeight: 1 }}>
            Your alternate selves
          </h1>

          {mbti && (
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '12px', background: `rgba(${mbtiInfo.color ? mbtiInfo.color.replace('#','').match(/.{2}/g).map(h=>parseInt(h,16)).join(',') : '93,216,232'},0.1)`, border: `1px solid ${mbtiInfo.color || '#5DD8E8'}40`, borderRadius: '100px', padding: '10px 24px', marginBottom: '12px' }}>
              <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '22px', fontWeight: 400, color: mbtiInfo.color || '#5DD8E8', letterSpacing: '0.08em' }}>{mbti}</span>
              <span style={{ width: '1px', height: '16px', background: 'rgba(255,255,255,0.12)' }} />
              <span style={{ fontSize: '13px', color: '#7880A0' }}>{mbtiInfo.name}</span>
            </div>
          )}
          <p style={{ fontSize: '14px', color: '#2E3455', marginTop: '6px' }}>
            Each branch is a life you could have lived. Click one to begin a conversation.
          </p>
        </div>

        <div style={{ maxWidth: '700px', margin: '0 auto 52px' }}>
          <PathTree personas={personas} onSelect={(p) => router.push(`/chat/${p.id}`)} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(270px, 1fr))', gap: '16px' }}>
          {personas.map((p) => (
            <Link key={p.id} href={`/chat/${p.id}`} style={{ textDecoration: 'none' }}>
              <div className="persona-card" style={{ '--pc': p.color }}>
                <div style={{ fontSize: '30px', marginBottom: '16px' }}>{p.emoji}</div>
                <div style={{ fontSize: '10px', letterSpacing: '0.14em', textTransform: 'uppercase', color: p.color, marginBottom: '6px' }}>{p.type}</div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '26px', fontWeight: 400, marginBottom: '8px' }}>{name}</div>
                <div style={{ fontSize: '13px', color: '#7880A0', lineHeight: 1.65, marginBottom: '16px' }}>{p.tagline}</div>
                {p.mbtiAlignment && (
                  <div style={{ fontSize: '12px', color: '#2E3455', borderLeft: `2px solid ${p.color}40`, paddingLeft: '10px', marginBottom: '16px', lineHeight: 1.6 }}>
                    {p.mbtiAlignment}
                  </div>
                )}
                <div style={{ borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: '16px' }}>
                  {p.timeline?.slice(0, 3).map((t, j) => (
                    <div key={j} style={{ display: 'flex', gap: '12px', marginBottom: '8px', alignItems: 'flex-start' }}>
                      <span style={{ fontSize: '11px', color: p.color, minWidth: '38px', fontWeight: 500, paddingTop: '1px' }}>{t.year}</span>
                      <span style={{ fontSize: '12px', color: '#7880A0', lineHeight: 1.55 }}>{t.event}</span>
                    </div>
                  ))}
                </div>
                <div style={{ marginTop: '18px', fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: p.color, opacity: 0, transition: 'opacity 0.3s' }} className="card-cta">
                  Chat with this version →
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: '60px' }}>
          <button className="btn-ghost" onClick={() => { localStorage.removeItem('butterfly_data'); router.push('/onboarding') }}>
            Start Over
          </button>
        </div>
      </div>

      <style>{`.persona-card:hover .card-cta { opacity: 1 !important; }`}</style>
    </main>
  )
}
