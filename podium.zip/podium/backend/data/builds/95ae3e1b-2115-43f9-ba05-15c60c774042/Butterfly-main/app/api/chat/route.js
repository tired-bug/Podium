import { NextResponse } from 'next/server'

export async function POST(req) {
  const body = await req.json()
  const { persona, userData, history, message } = body

  const tlStr = persona.timeline?.map(t => `${t.year}: ${t.event}`).join('; ') || ''

  const systemPrompt = `You are ${userData.name}'s alternate self — specifically, the version of them who became a ${persona.type}.

Who you became: ${persona.description}
Your life path: ${tlStr}
Your speaking tone: ${persona.tone}
Your MBTI connection: ${persona.mbtiAlignment}

The person you're speaking to has MBTI type ${userData.mbti}. They are currently: ${userData.role}.
Their goals: ${userData.goals}
Their fears: ${userData.fears}

Speak in first person as this alternate self who remembers being exactly where ${userData.name} is now.
You have the wisdom of hindsight — you lived through their exact fears and came out the other side.
Weave in their specific goals and fears when naturally relevant.
Be emotionally honest. Be specific. Be occasionally vulnerable.
Respond in 2-3 short paragraphs. Never break character. Never mention you are an AI.`

  const messages = [
    ...history.map(m => ({ role: m.role, content: m.content })),
    { role: 'user', content: message },
  ]

  try {
    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'llama-3.3-70b-versatile',
        messages: [
          { role: 'system', content: systemPrompt },
          ...messages,
        ],
        max_tokens: 512,
        temperature: 0.9,
      }),
    })

    const data = await res.json()
    if (!res.ok) throw new Error(data.error?.message || 'Groq API error')

    const reply = data.choices?.[0]?.message?.content || '…'
    return NextResponse.json({ reply })
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
