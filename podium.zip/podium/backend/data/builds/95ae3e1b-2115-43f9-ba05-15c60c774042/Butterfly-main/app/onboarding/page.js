'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Stars from '@/components/Stars'
import ButterflyIcon from '@/components/ButterflyIcon'
import { QUESTIONS, calculateMBTI, TYPES } from '@/lib/mbti'

const TRAITS = [
  'Ambitious', 'Introverted', 'Creative', 'Analytical', 'Risk-taker',
  'Empathetic', 'Independent', 'Disciplined', 'Adventurous', 'Perfectionist',
  'Curious', 'Resilient', 'Idealistic', 'Pragmatic', 'Collaborative',
]

const TOTAL_STEPS = 5

export default function OnboardingPage() {
  const router = useRouter()
  const [step, setStep] = useState(0)
  const [form, setForm] = useState({ name: '', role: '', skills: '', traits: [], goals: '', fears: '' })
  const [quizIndex, setQuizIndex] = useState(0)
  const [quizAnswers, setQuizAnswers] = useState([])
  const [mbtiResult, setMbtiResult] = useState(null)
  const [showMbtiReveal, setShowMbtiReveal] = useState(false)
  const [generating, setGenerating] = useState(false)
  const [error, setError] = useState('')

  const toggleTrait = (t) => setForm(p => ({ ...p, traits: p.traits.includes(t) ? p.traits.filter(x => x !== t) : [...p.traits, t] }))

  const canAdvance = () => {
    if (step === 0) return form.name.trim() && form.role.trim()
    if (step === 1) return form.skills.trim()
    if (step === 2) return form.traits.length > 0
    if (step === 3) return form.goals.trim() && form.fears.trim()
    return false
  }

  const handleQuizAnswer = (val) => {
    const updated = [...quizAnswers, val]
    setQuizAnswers(updated)
    if (updated.length === QUESTIONS.length) {
      const type = calculateMBTI(updated)
      setMbtiResult(type)
      setShowMbtiReveal(true)
    } else {
      setQuizIndex(i => i + 1)
    }
  }

  useEffect(() => {
    if (showMbtiReveal) {
      const t = setTimeout(() => handleGenerate(mbtiResult), 2800)
      return () => clearTimeout(t)
    }
  }, [showMbtiReveal])

  const handleGenerate = async (type) => {
    setGenerating(true)
    setError('')
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, mbti: type }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      localStorage.setItem('butterfly_data', JSON.stringify({ ...form, mbti: type, mbtiType: TYPES[type], personas: data.personas }))
      router.push('/explore')
    } catch (e) {
      setError(e.message || 'Something went wrong. Check your API key.')
      setGenerating(false)
      setShowMbtiReveal(false)
    }
  }

  if (generating && !showMbtiReveal) {
    return <GeneratingScreen name={form.name} />
  }

  if (showMbtiReveal && mbtiResult) {
    const type = TYPES[mbtiResult]
    return (
      <main style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 24px' }}>
        <Stars />
        <div style={{ position: 'relative', zIndex: 1, textAlign: 'center', maxWidth: '480px' }}>
          <div style={{ marginBottom: '24px', opacity: 0.5 }}><ButterflyIcon size={56} /></div>
          <p style={{ fontSize: '12px', letterSpacing: '0.18em', textTransform: 'uppercase', color: '#5DD8E8', marginBottom: '28px' }}>Your MBTI Type</p>
          <div className="mbti-reveal" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 'clamp(72px, 14vw, 100px)', fontWeight: 300, lineHeight: 1, marginBottom: '20px', background: `linear-gradient(135deg, ${type?.color || '#5DD8E8'}, #EEF0FA)`, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
            {mbtiResult}
          </div>
          <p style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '28px', fontWeight: 300, fontStyle: 'italic', color: '#EEF0FA', marginBottom: '16px' }}>{type?.name}</p>
          <p style={{ fontSize: '15px', color: '#7880A0', lineHeight: 1.75, marginBottom: '40px' }}>{type?.desc}</p>
          <p style={{ fontSize: '13px', color: '#2E3455', letterSpacing: '0.06em' }}>Weaving your alternate selves…</p>
        </div>
      </main>
    )
  }

  if (step === 4) {
    const q = QUESTIONS[quizIndex]
    const progress = (quizIndex / QUESTIONS.length) * 100
    return (
      <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '60px 20px' }}>
        <Stars />
        <div style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: '540px' }}>
          <div style={{ textAlign: 'center', marginBottom: '40px' }}>
            <p style={{ fontSize: '11px', letterSpacing: '0.18em', textTransform: 'uppercase', color: '#5DD8E8', marginBottom: '12px' }}>MBTI Assessment · {quizIndex + 1} of {QUESTIONS.length}</p>
            <div className="progress-bar" style={{ marginBottom: '32px' }}>
              <div className="progress-fill" style={{ width: `${progress}%` }} />
            </div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 'clamp(22px, 4vw, 32px)', fontWeight: 300, fontStyle: 'italic', lineHeight: 1.4 }}>{q.text}</h2>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <button className="quiz-option" onClick={() => handleQuizAnswer('a')}>
              <span style={{ display: 'block', fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#5DD8E8', marginBottom: '6px' }}>A</span>
              {q.a}
            </button>
            <button className="quiz-option" onClick={() => handleQuizAnswer('b')}>
              <span style={{ display: 'block', fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#B57BF5', marginBottom: '6px' }}>B</span>
              {q.b}
            </button>
          </div>
          <p style={{ textAlign: 'center', marginTop: '28px', fontSize: '12px', color: '#2E3455' }}>Be honest — there are no right or wrong answers</p>
        </div>
      </main>
    )
  }

  const stepLabels = ['About You', 'Your Background', 'Your Personality', 'Your Journey']
  const stepTitles = [
    'Who are you right now?',
    'What have you built so far?',
    'How would you describe yourself?',
    'What drives and scares you?',
  ]

  return (
    <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '60px 20px 80px' }}>
      <Stars />
      <div style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: '560px' }}>
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <p style={{ fontSize: '11px', letterSpacing: '0.18em', textTransform: 'uppercase', color: '#5DD8E8', marginBottom: '10px' }}>{stepLabels[step]}</p>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 'clamp(28px, 5vw, 44px)', fontWeight: 300, fontStyle: 'italic' }}>{stepTitles[step]}</h2>
        </div>

        <div className="glass" style={{ borderRadius: '24px', padding: '40px' }}>
          {step === 0 && (
            <>
              <div style={{ marginBottom: '24px' }}>
                <label style={{ display: 'block', fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7880A0', marginBottom: '10px' }}>Your name</label>
                <input className="input-field" placeholder="What do people call you?" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7880A0', marginBottom: '10px' }}>Current role or situation</label>
                <input className="input-field" placeholder="Student, designer, between things…" value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))} />
              </div>
            </>
          )}

          {step === 1 && (
            <div>
              <label style={{ display: 'block', fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7880A0', marginBottom: '10px' }}>Skills & background</label>
              <textarea className="input-field" placeholder="What are you good at? What have you built, studied, or done?" value={form.skills} onChange={e => setForm(p => ({ ...p, skills: e.target.value }))} />
              <p style={{ fontSize: '12px', color: '#2E3455', marginTop: '10px' }}>The more specific you are, the more personal your alternate selves become.</p>
            </div>
          )}

          {step === 2 && (
            <div>
              <label style={{ display: 'block', fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7880A0', marginBottom: '14px' }}>Pick traits that describe you</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {TRAITS.map(t => (
                  <button key={t} className={`trait-chip ${form.traits.includes(t) ? 'active' : ''}`} onClick={() => toggleTrait(t)}>{t}</button>
                ))}
              </div>
            </div>
          )}

          {step === 3 && (
            <>
              <div style={{ marginBottom: '24px' }}>
                <label style={{ display: 'block', fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7880A0', marginBottom: '10px' }}>Your biggest goals</label>
                <textarea className="input-field" placeholder="What do you want to build, become, or experience in your lifetime?" value={form.goals} onChange={e => setForm(p => ({ ...p, goals: e.target.value }))} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7880A0', marginBottom: '10px' }}>Your deepest fears</label>
                <textarea className="input-field" placeholder="What holds you back? What keeps you up at night?" value={form.fears} onChange={e => setForm(p => ({ ...p, fears: e.target.value }))} />
              </div>
            </>
          )}

          {error && <p style={{ color: '#E86C8F', fontSize: '13px', marginTop: '16px', textAlign: 'center' }}>{error}</p>}

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '36px' }}>
            <div style={{ display: 'flex', gap: '6px' }}>
              {[0, 1, 2, 3, 4].map(i => (
                <div key={i} style={{ height: '6px', borderRadius: '3px', background: i === step ? '#5DD8E8' : '#2E3455', width: i === step ? '20px' : '6px', transition: 'all 0.3s' }} />
              ))}
            </div>
            <div style={{ display: 'flex', gap: '10px' }}>
              {step > 0 && <button className="btn-ghost" onClick={() => setStep(s => s - 1)}>← Back</button>}
              {step < 3 ? (
                <button className="btn-primary" disabled={!canAdvance()} onClick={() => setStep(s => s + 1)}>Continue →</button>
              ) : (
                <button className="btn-primary" disabled={!canAdvance()} onClick={() => setStep(4)}>Take MBTI Quiz →</button>
              )}
            </div>
          </div>
        </div>

        {step === 4 && (
          <p style={{ textAlign: 'center', marginTop: '16px', fontSize: '12px', color: '#2E3455' }}>
            Next: a 16-question personality quiz to personalize your alternate selves
          </p>
        )}
      </div>
    </main>
  )
}

function GeneratingScreen({ name }) {
  const rings = [
    { size: 64, dur: '3s', color: '#5DD8E8', rev: false },
    { size: 96, dur: '4.2s', color: '#F0A558', rev: true },
    { size: 128, dur: '5.5s', color: '#B57BF5', rev: false },
    { size: 160, dur: '7s', color: '#E86C8F', rev: true },
    { size: 192, dur: '8.5s', color: '#5DE8A0', rev: false },
  ]
  return (
    <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px', textAlign: 'center' }}>
      <Stars />
      <div style={{ position: 'relative', zIndex: 1 }}>
        <div style={{ position: 'relative', width: '220px', height: '220px', margin: '0 auto 40px' }}>
          <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', zIndex: 2 }}>
            <ButterflyIcon size={52} />
          </div>
          {rings.map((r, i) => (
            <div key={i} style={{
              position: 'absolute', top: '50%', left: '50%',
              width: `${r.size}px`, height: `${r.size}px`,
              borderRadius: '50%', border: '1px solid rgba(255,255,255,0.06)',
              animation: `orbitSpin ${r.dur} linear infinite ${r.rev ? 'reverse' : 'normal'}`,
            }}>
              <div style={{ position: 'absolute', width: '9px', height: '9px', borderRadius: '50%', background: r.color, top: '-4.5px', left: '50%', marginLeft: '-4.5px', boxShadow: `0 0 8px ${r.color}` }} />
            </div>
          ))}
        </div>
        <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '38px', fontWeight: 300, fontStyle: 'italic', marginBottom: '12px' }}>
          Weaving your alternate lives…
        </h2>
        <p style={{ color: '#7880A0', fontSize: '15px' }}>
          Exploring the paths you never took, {name}
        </p>
      </div>
    </main>
  )
}
