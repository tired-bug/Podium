import { NextResponse } from 'next/server'

const MBTI_DESCRIPTIONS = {
  INTJ: "Strategic, independent visionary — they plan far ahead and trust their own judgment",
  INTP: "Curious, inventive thinker — they love ideas over people and systems over rules",
  ENTJ: "Decisive natural leader — they command rooms and build empires from nothing",
  ENTP: "Quick-witted innovator — they thrive on disrupting the status quo",
  INFJ: "Insightful idealist — they see the big picture and act with deep purpose",
  INFP: "Creative mediator — they're guided by values and a longing to make things meaningful",
  ENFJ: "Charismatic protagonist — they inspire others to become their best selves",
  ENFP: "Enthusiastic campaigner — they see possibility everywhere and connect everything",
  ISTJ: "Reliable logistician — they honor commitment and build sturdy, lasting things",
  ISFJ: "Devoted defender — they quietly protect and nourish the people around them",
  ESTJ: "Organized executive — they create order and expect others to rise to it",
  ESFJ: "Caring consul — they thrive through relationships and community belonging",
  ISTP: "Practical virtuoso — they master tools and solve problems with elegant efficiency",
  ISFP: "Gentle adventurer — they express themselves through art and live in the present",
  ESTP: "Bold entrepreneur — they act first, assess second, and rarely look back",
  ESFP: "Vibrant entertainer — they make everything more alive just by being present",
}

export async function POST(req) {
  const body = await req.json()
  const { name, role, skills, traits, goals, fears, mbti } = body
  const mbtiDesc = MBTI_DESCRIPTIONS[mbti] || mbti

  const systemPrompt = `You are a creative life-narrative AI for Butterfly, a self-exploration platform.
Generate exactly 5 alternate-life personas personalized deeply to this user's profile and MBTI type.
Return ONLY a valid JSON array — no markdown, no code fences, no extra text.

Each persona must follow this exact structure:
{
  "id": number,
  "type": string,
  "emoji": string,
  "color": string,
  "tagline": string,
  "description": string,
  "tone": string,
  "mbtiAlignment": string,
  "timeline": [{"year": string, "event": string}, {"year": string, "event": string}, {"year": string, "event": string}],
  "openingMessage": string
}

Rules:
- "description": 2-3 sentences about who this version became. Reference specific skills and background.
- "tone": their speaking style in 6-8 words
- "mbtiAlignment": one sentence explaining how this path relates to the user's ${mbti} type specifically
- "timeline": exactly 3 events with concrete years starting from ~2025-2026
- "openingMessage": 2-3 sentences speaking directly to the user as if they found a letter from themselves. Reference their specific goals or fears. Emotionally resonant. First person.

The 5 personas must be exactly in this order:
1. id:1, type:"Startup Founder", emoji:"🚀", color:"#F0A558"
2. id:2, type:"World Traveler", emoji:"🌏", color:"#5DD8E8"
3. id:3, type:"Creative Artist", emoji:"🎨", color:"#B57BF5"
4. id:4, type:"Academic Researcher", emoji:"🔬", color:"#E86C8F"
5. id:5, type:"Future Self", emoji:"✨", color:"#5DE8A0"

Make every field deeply personal — not generic. Use their actual skills, role, and fears.`

  const userMsg = `Name: ${name}
Current role: ${role}
Skills & background: ${skills}
Personality traits: ${(traits || []).join(', ')}
Goals: ${goals}
Fears: ${fears}
MBTI Type: ${mbti} — ${mbtiDesc}`

  try {
    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'llama-3.3-70b-versatile',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userMsg },
        ],
        max_tokens: 2048,
        temperature: 0.85,
      }),
    })

    const data = await res.json()
    if (!res.ok) throw new Error(data.error?.message || 'Groq API error')

    const raw = data.choices?.[0]?.message?.content || '[]'
    const clean = raw.replace(/```json\n?|```/g, '').trim()
    const personas = JSON.parse(clean)
    return NextResponse.json({ personas })
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
