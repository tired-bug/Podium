'use client'
import { useEffect, useState, useRef } from 'react'
import { useRouter, useParams } from 'next/navigation'
import Link from 'next/link'
import Stars from '@/components/Stars'
import { TYPES } from '@/lib/mbti'

export default function ChatPage() {
  const router = useRouter()
  const params = useParams()
  const [data, setData] = useState(null)
  const [persona, setPersona] = useState(null)
  const [msgs, setMsgs] = useState([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const bottomRef = useRef(null)
  const inputRef = useRef(null)
  const storageKey = useRef('')

  useEffect(() => {
    const raw = localStorage.getItem('butterfly_data')
    if (!raw) { router.push('/onboarding'); return }
    const parsed = JSON.parse(raw)
    setData(parsed)
    const p = parsed.personas?.find(x => String(x.id) === String(params.personaId))
    if (!p) { router.push('/explore'); return }
    setPersona(p)
    storageKey.current = `butterfly_chat_${parsed.name}_${p.id}`
    const saved = localStorage.getItem(storageKey.current)
    if (saved) {
      setMsgs(JSON.parse(saved))
    } else {
      const opening = [{ role: 'assistant', content: p.openingMessage }]
      setMsgs(opening)
      localStorage.setItem(storageKey.current, JSON.stringify(opening))
    }
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [msgs, busy])

  const saveMessages = (m) => {
    if (storageKey.current) localStorage.setItem(storageKey.current, JSON.stringify(m))
  }

  const doSend = async () => {
    if (!input.trim() || busy) return
    const txt = input.trim()
    setInput('')
    const next = [...msgs, { role: 'user', content: txt }]
    setMsgs(next)
    saveMessages(next)
    setBusy(true)
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ persona, userData: data, history: msgs, message: txt }),
      })
      const result = await res.json()
      const final = [...next, { role: 'assistant', content: result.reply }]
      setMsgs(final)
      saveMessages(final)
    } catch {
      const final = [...next, { role: 'assistant', content: 'The connection faded for a moment… try again.' }]
      setMsgs(final)
    }
    setBusy(false)
    setTimeout(() => inputRef.current?.focus(), 50)
  }

  if (!persona || !data) return (
    <main style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Stars />
    </main>
  )

  const mbtiInfo = TYPES[data.mbti] || {}

  return (
    <main style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: '#06081A', position: 'relative' }}>
      <Stars />

      <div style={{ display: 'flex', alignItems: 'center', gap: '16px', padding: '16px 24px', borderBottom: '1px solid rgba(255,255,255,0.08)', background: 'rgba(6,8,26,0.9)', backdropFilter: 'blur(24px)', flexShrink: 0, position: 'relative', zIndex: 2 }}>
        <Link href="/explore" style={{ background: 'none', border: 'none', color: '#7880A0', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', textDecoration: 'none', transition: 'color 0.2s' }}>
          ← All paths
        </Link>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '10px', letterSpacing: '0.14em', textTransform: 'uppercase', color: persona.color, marginBottom: '2px' }}>
            {persona.emoji} {persona.type}
          </div>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '20px', fontWeight: 400 }}>{data.name}</div>
        </div>
        {data.mbti && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '100px', padding: '6px 14px' }}>
            <span style={{ fontSize: '12px', color: mbtiInfo.color || '#5DD8E8', fontWeight: 500 }}>{data.mbti}</span>
            <span style={{ fontSize: '11px', color: '#2E3455' }}>·</span>
            <span style={{ fontSize: '11px', color: '#7880A0' }}>{mbtiInfo.name}</span>
          </div>
        )}
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '36px 20px', display: 'flex', flexDirection: 'column', gap: '28px', maxWidth: '700px', width: '100%', margin: '0 auto', position: 'relative', zIndex: 1 }}>
        {msgs.map((m, i) => (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: '5px', alignItems: m.role === 'user' ? 'flex-end' : 'flex-start' }}>
            <div style={{ fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#2E3455' }}>
              {m.role === 'user' ? `${data.name} · present` : `${data.name} · ${persona.type}`}
            </div>
            <div style={{
              maxWidth: '82%', padding: '16px 20px', fontSize: '14px', lineHeight: 1.75, fontWeight: 300,
              borderRadius: '20px',
              ...(m.role === 'user'
                ? { background: 'rgba(93,216,232,0.1)', border: '1px solid rgba(93,216,232,0.2)', borderBottomRightRadius: '5px' }
                : { background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderLeft: `3px solid ${persona.color}`, borderBottomLeftRadius: '5px' }
              )
            }}>
              {m.content}
            </div>
          </div>
        ))}

        {busy && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '5px', alignItems: 'flex-start' }}>
            <div style={{ fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#2E3455' }}>
              {data.name} · {persona.type}
            </div>
            <div style={{ display: 'flex', gap: '5px', padding: '14px 18px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderLeft: `3px solid ${persona.color}`, borderRadius: '20px', borderBottomLeftRadius: '5px' }}>
              <div className="typing-dot" />
              <div className="typing-dot" />
              <div className="typing-dot" />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div style={{ padding: '16px 20px', borderTop: '1px solid rgba(255,255,255,0.08)', background: 'rgba(6,8,26,0.9)', backdropFilter: 'blur(24px)', flexShrink: 0, position: 'relative', zIndex: 2 }}>
        <div style={{ display: 'flex', gap: '12px', maxWidth: '700px', margin: '0 auto', alignItems: 'flex-end' }}>
          <textarea
            ref={inputRef}
            style={{
              flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '16px',
              color: '#EEF0FA', fontFamily: "'DM Sans', sans-serif", fontSize: '14px', fontWeight: 300,
              padding: '14px 18px', resize: 'none', outline: 'none', minHeight: '52px', maxHeight: '160px',
              transition: 'border-color 0.2s',
            }}
            placeholder="Ask your alternate self anything…"
            value={input}
            rows={1}
            onChange={e => setInput(e.target.value)}
            onFocus={e => e.target.style.borderColor = '#5DD8E8'}
            onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.08)'}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSend() } }}
          />
          <button
            onClick={doSend}
            disabled={!input.trim() || busy}
            style={{
              background: 'linear-gradient(135deg, #5DD8E8, #B57BF5)', border: 'none', borderRadius: '14px',
              width: '52px', height: '52px', cursor: 'pointer', display: 'flex', alignItems: 'center',
              justifyContent: 'center', flexShrink: 0, transition: 'transform 0.2s, box-shadow 0.2s',
              opacity: (!input.trim() || busy) ? 0.35 : 1,
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" stroke="#06081A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>
        <p style={{ textAlign: 'center', fontSize: '11px', color: '#2E3455', marginTop: '8px' }}>
          Enter to send · Shift+Enter for new line · Chat history is saved locally
        </p>
      </div>
    </main>
  )
}
