/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
    './lib/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        'bf-bg': '#06081A',
        'bf-teal': '#5DD8E8',
        'bf-violet': '#B57BF5',
        'bf-amber': '#F0A558',
        'bf-rose': '#E86C8F',
        'bf-green': '#5DE8A0',
        'bf-text': '#EEF0FA',
        'bf-muted': '#7880A0',
        'bf-subtle': '#2E3455',
        'bf-surface': 'rgba(255,255,255,0.04)',
      },
      fontFamily: {
        display: ['var(--font-display)', 'serif'],
        body: ['var(--font-body)', 'sans-serif'],
      },
      animation: {
        'float': 'float 4.5s ease-in-out infinite',
        'twinkle': 'twinkle 3s ease-in-out infinite alternate',
        'spin-slow': 'spin 8s linear infinite',
        'fade-up': 'fadeUp 0.6s ease forwards',
        'scale-in': 'scaleIn 0.3s ease forwards',
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-14px)' },
        },
        twinkle: {
          from: { opacity: '0.1' },
          to: { opacity: '0.8' },
        },
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(20px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        scaleIn: {
          from: { opacity: '0', transform: 'scale(0.9)' },
          to: { opacity: '1', transform: 'scale(1)' },
        },
        pulseGlow: {
          '0%,100%': { boxShadow: '0 0 20px rgba(93,216,232,0.2)' },
          '50%': { boxShadow: '0 0 40px rgba(93,216,232,0.5)' },
        },
      },
    },
  },
  plugins: [],
}
