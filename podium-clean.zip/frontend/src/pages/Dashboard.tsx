import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Rocket, FileText,
  TrendingUp, TrendingDown, RefreshCw,
  Activity, Zap, Search,
} from 'lucide-react';
import { Card, Badge, EmptyState } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { MetricChart } from '../components/charts/MetricChart';
import { timeAgo } from '../lib/utils';
import api from '../lib/api';

function StatCard({
  label, value, icon, gradient, trend, onClick, delay = 0,
}: {
  label: string; value: number | string; icon: React.ReactNode;
  gradient: string; trend?: number; onClick?: () => void; delay?: number;
}) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        padding: '20px', borderRadius: 'var(--r-lg)',
        background: hovered ? 'var(--bg-card-hover)' : 'var(--bg-card)',
        border: `1px solid ${hovered ? 'var(--border-glow)' : 'var(--border)'}`,
        cursor: onClick ? 'pointer' : 'default',
        transition: 'all 200ms ease',
        transform: hovered ? 'translateY(-3px)' : 'translateY(0)',
        boxShadow: hovered ? 'var(--shadow-lg)' : 'var(--shadow-card)',
        animation: `float-up 350ms ease-out ${delay}ms both`,
        position: 'relative', overflow: 'hidden',
      }}
    >
      {}
      <div style={{
        position: 'absolute', inset: 0, opacity: hovered ? 0.08 : 0,
        background: gradient, transition: 'opacity 200ms',
      }} />

      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', position: 'relative' }}>
        <div>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: 8, fontWeight: 500, letterSpacing: '.03em', textTransform: 'uppercase' }}>
            {label}
          </div>
          <div className="stat-value" style={{ fontSize: '32px', fontWeight: 900, color: 'var(--text-primary)', lineHeight: 1, letterSpacing: '-.02em' }}>
            {value}
          </div>
          {trend !== undefined && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 8, fontSize: '11px', color: trend >= 0 ? 'var(--accent-green)' : 'var(--accent-red)' }}>
              {trend >= 0 ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
              {Math.abs(trend)}% this week
            </div>
          )}
        </div>
        <div style={{
          width: 44, height: 44, borderRadius: 'var(--r-lg)', flexShrink: 0,
          background: gradient, display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: hovered ? '0 4px 16px rgba(99,102,241,.4)' : 'none',
          transition: 'box-shadow 200ms',
        }}>
          {icon}
        </div>
      </div>
    </div>
  );
}

function ReportRow({ report, onOpen }: { report: any; onOpen: (r: any) => void }) {
  const isIncident = report.type === 'incident';
  const color = isIncident ? '#a855f7' : '#f59e0b';
  return (
    <div
      onClick={() => onOpen(report)}
      style={{
        padding: '10px 12px', borderRadius: 'var(--r-md)',
        background: 'var(--bg-elevated)',
        borderLeft: `3px solid ${color}`,
        display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8,
        animation: 'float-up 250ms ease-out both',
        cursor: 'pointer', transition: 'all 200ms',
      }}
    >
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2, flexWrap: 'wrap' }}>
          <span style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-primary)' }}>{report.deployment_name}</span>
          <span style={{ fontSize: '10px', fontWeight: 700, padding: '1px 6px', borderRadius: 'var(--r-pill)', background: color + '20', color }}>
            {isIncident ? 'Incident' : 'Root Cause'}
          </span>
        </div>
        <div style={{ fontSize: '11px', color: 'var(--text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {report.content.replace(/[#*_`]/g, '').slice(0, 90)}
        </div>
        <div style={{ fontSize: '10px', color: 'var(--text-muted)', marginTop: 3 }}>{timeAgo(report.created_at)}</div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [loading,    setLoading]    = useState(true);
  const [reports,    setReports]    = useState<any[]>([]);
  const [cloudDeps,  setCloudDeps]  = useState<any[]>([]);
  const [metrics,    setMetrics]    = useState<any[]>([]);

  const fetchAll = useCallback(async () => {
    const [reportsRes, cloudRes] = await Promise.allSettled([
      api.get('/api/ai/reports'),
      api.get('/api/cloud'),
    ]);
    if (reportsRes.status === 'fulfilled') setReports(reportsRes.value.data);
    if (cloudRes.status === 'fulfilled') setCloudDeps(cloudRes.value.data);

    const days = Array.from({ length: 7 }, (_, i) => ({
      timestamp: Date.now() - (6 - i) * 86_400_000,
      successRate: 82 + Math.random() * 18,
    }));
    setMetrics(days);
    setLoading(false);
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  // "Total Deployments" counts every deployment on the platform. Real deploys
  // all go through the cloud provider engine now (see /api/cloud), so that's
  // the single source of truth — not the legacy/local `deployments` table.
  const totalDeployments = cloudDeps.length;

  const statCards = [
    { label: 'Total Deployments', value: totalDeployments, icon: <Rocket size={20} color="#fff" />, gradient: 'linear-gradient(135deg,#6366f1,#a855f7)', onClick: () => navigate('/cloud') },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      {}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', animation: 'float-up 250ms ease-out' }}>
        <div>
          <h1 style={{ fontSize: '22px', fontWeight: 900, margin: 0, letterSpacing: '-.01em' }}>Dashboard</h1>
          <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: 3 }}>Platform health at a glance</p>
        </div>
        <Button icon={<RefreshCw size={14} />} onClick={() => { setLoading(true); fetchAll(); }} size="sm">Refresh</Button>
      </div>

      {}
      <div className="anim-grid" style={{ display: 'grid', gridTemplateColumns: 'minmax(220px, 300px)', gap: 16 }}>
        {loading
          ? <div className="skeleton" style={{ height: 110, borderRadius: 'var(--r-lg)' }} />
          : statCards.map((c, i) => <StatCard key={c.label} {...c} delay={i * 60} />)
        }
      </div>

      {}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16 }}>
        {}
        <Card style={{ animation: 'float-up 350ms ease-out 240ms both' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <div style={{ fontSize: '14px', fontWeight: 700 }}>Deployment Health</div>
            <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Last 7 days</span>
          </div>
          <MetricChart
            data={metrics}
            lines={[{ key: 'successRate', label: 'Success Rate', color: 'var(--accent-green)' }]}
            type="area" unit="%" height={160} yDomain={[0, 100]}
          />
        </Card>

        {}
        <Card style={{ display: 'flex', flexDirection: 'column', animation: 'float-up 350ms ease-out 300ms both' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <div style={{ fontSize: '14px', fontWeight: 700 }}>Recent AI Reports</div>
            {reports.length > 0 && (
              <span style={{ fontSize: '10px', fontWeight: 700, padding: '2px 8px', borderRadius: 'var(--r-pill)', background: 'var(--accent-blue-dim)', color: 'var(--accent-blue-2)' }}>
                {reports.length}
              </span>
            )}
          </div>
          {reports.length === 0 ? (
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, padding: '12px 0' }}>
              <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'var(--accent-blue-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <FileText size={20} color="var(--accent-blue-2)" />
              </div>
              <div style={{ fontSize: '12px', color: 'var(--text-secondary)', textAlign: 'center' }}>No reports generated yet</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, overflowY: 'auto', maxHeight: 220, flex: 1 }}>
              {reports.slice(0, 4).map(r => (
                <ReportRow key={r.id} report={r} onOpen={() => navigate('/ai/hub')} />
              ))}
            </div>
          )}
          {reports.length > 0 && (
            <Button size="sm" variant="ghost" fullWidth icon={<Search size={12} />} onClick={() => navigate('/ai/hub')} style={{ marginTop: 10 }}>
              Open AI Hub
            </Button>
          )}
        </Card>
      </div>

      {}
      <Card style={{ padding: 0, overflow: 'hidden', animation: 'float-up 350ms ease-out 360ms both' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 20px', borderBottom: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 30, height: 30, borderRadius: 'var(--r-md)', background: 'linear-gradient(135deg,#6366f1,#a855f7)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Activity size={15} color="#fff" />
            </div>
            <div>
              <div style={{ fontSize: '14px', fontWeight: 700 }}>Recent Deployments</div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{cloudDeps.length} total</div>
            </div>
          </div>
          <Button size="sm" variant="ghost" onClick={() => navigate('/cloud')}>View all →</Button>
        </div>

        {loading ? (
          <div style={{ padding: '12px 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[1, 2, 3].map(i => <div key={i} className="skeleton" style={{ height: 44 }} />)}
          </div>
        ) : cloudDeps.length === 0 ? (
          <EmptyState icon="🚀" title="No deployments yet"
            description="Deploy your first project to get started."
            action={<Button variant="primary" size="sm" onClick={() => navigate('/cloud')}>New Deployment</Button>}
          />
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%' }}>
              <thead>
                <tr style={{ background: 'var(--bg-secondary)' }}>
                  {['Name', 'Status', 'Provider', 'Region', 'Updated'].map(h => (
                    <th key={h} style={{ padding: '9px 20px', fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '.06em', fontWeight: 600, textAlign: 'left' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[...cloudDeps]
                  .sort((a, b) => new Date(b.updated_at || b.created_at).getTime() - new Date(a.updated_at || a.created_at).getTime())
                  .slice(0, 8)
                  .map((d, i) => (
                  <tr
                    key={d.id}
                    onClick={() => navigate('/cloud')}
                    style={{
                      borderTop: '1px solid var(--border-muted)',
                      cursor: 'pointer', transition: 'background 120ms',
                      animation: `float-up 250ms ease-out ${i * 40}ms both`,
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-glass-light)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                  >
                    <td style={{ padding: '12px 20px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ width: 28, height: 28, borderRadius: 7, background: 'linear-gradient(135deg,var(--accent-blue-dim),var(--accent-purple-dim))', border: '1px solid var(--border-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <Zap size={12} color="var(--accent-blue-2)" />
                        </div>
                        <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--text-primary)' }}>{d.name}</span>
                      </div>
                    </td>
                    <td style={{ padding: '12px 20px' }}><Badge variant="status" value={d.status}>{d.status}</Badge></td>
                    <td style={{ padding: '12px 20px', fontSize: '12px', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)', textTransform: 'capitalize' }}>{d.provider}</td>
                    <td style={{ padding: '12px 20px', fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{d.region || '—'}</td>
                    <td style={{ padding: '12px 20px', fontSize: '12px', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{timeAgo(d.updated_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
